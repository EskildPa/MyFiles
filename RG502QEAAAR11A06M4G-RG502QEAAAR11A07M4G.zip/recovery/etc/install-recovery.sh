#!/system/bin/sh
if ! applypatch -c MTD:recovery:10672128:d3d5e08da527a4bd6b1d31074886a060178b3c54; then
  log -t recovery "Installing new recovery image"
  applypatch MTD:boot:10672128:d3d5e08da527a4bd6b1d31074886a060178b3c54 MTD:recovery d3d5e08da527a4bd6b1d31074886a060178b3c54 10672128 d3d5e08da527a4bd6b1d31074886a060178b3c54:/system/recovery-from-boot.p
else
  log -t recovery "Recovery image already installed"
fi
